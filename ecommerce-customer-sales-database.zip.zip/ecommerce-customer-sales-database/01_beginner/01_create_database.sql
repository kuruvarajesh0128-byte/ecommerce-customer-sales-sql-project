IF DB_ID('EcommerceDB') IS NULL
BEGIN
    CREATE DATABASE EcommerceDB;
END;
GO

USE EcommerceDB;
GO

SELECT DB_NAME() AS CurrentDatabase;
GO
USE EcommerceDB;
GO
IF OBJECT_ID('dbo.OrderItems','U') IS NOT NULL DROP TABLE dbo.OrderItems;
IF OBJECT_ID('dbo.Orders','U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID('dbo.Products','U') IS NOT NULL DROP TABLE dbo.Products;
IF OBJECT_ID('dbo.Customers','U') IS NOT NULL DROP TABLE dbo.Customers;
GO
CREATE TABLE dbo.Customers (
 CustomerID INT IDENTITY(1,1) PRIMARY KEY,
 CustomerName VARCHAR(100) NOT NULL,
 Email VARCHAR(150) NOT NULL UNIQUE,
 Gender VARCHAR(20) NULL,
 City VARCHAR(80) NULL,
 SignupDate DATE NOT NULL DEFAULT (CAST(GETDATE() AS DATE))
);
CREATE TABLE dbo.Products (
 ProductID INT IDENTITY(1,1) PRIMARY KEY,
 ProductName VARCHAR(120) NOT NULL,
 Category VARCHAR(60) NOT NULL,
 UnitPrice DECIMAL(10,2) NOT NULL CHECK (UnitPrice >= 0),
 StockQuantity INT NOT NULL DEFAULT 0 CHECK (StockQuantity >= 0)
);
CREATE TABLE dbo.Orders (
 OrderID INT IDENTITY(1,1) PRIMARY KEY,
 CustomerID INT NOT NULL,
 OrderDate DATE NOT NULL DEFAULT (CAST(GETDATE() AS DATE)),
 OrderStatus VARCHAR(20) NOT NULL DEFAULT 'Pending'
   CHECK (OrderStatus IN ('Pending','Processing','Shipped','Delivered','Cancelled')),
 FOREIGN KEY (CustomerID) REFERENCES dbo.Customers(CustomerID)
);
CREATE TABLE dbo.OrderItems (
 OrderItemID INT IDENTITY(1,1) PRIMARY KEY,
 OrderID INT NOT NULL,
 ProductID INT NOT NULL,
 Quantity INT NOT NULL CHECK (Quantity > 0),
 UnitPrice DECIMAL(10,2) NOT NULL CHECK (UnitPrice >= 0),
 CONSTRAINT UQ_OrderItems_Order_Product UNIQUE (OrderID, ProductID),
 FOREIGN KEY (OrderID) REFERENCES dbo.Orders(OrderID),
 FOREIGN KEY (ProductID) REFERENCES dbo.Products(ProductID)
);
GO

SELECT * FROM dbo.Customers
SELECT * FROM dbo.Products
SELECT * FROM dbo.Orders
SELECT * FROM dbo.OrderItems


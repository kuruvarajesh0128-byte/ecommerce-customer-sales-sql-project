-- Project: E-Commerce Customer & Sales Database
-- Purpose: Insert sample customer records

USE EcommerceDB;
GO

INSERT INTO dbo.Customers (CustomerName,Email,Gender,City,SignupDate) VALUES
('Asha Rao','asha@example.com','Female','Bengaluru','2025-01-10'),
('Ravi Kumar','ravi@example.com','Male','Hyderabad','2025-02-14'),
('Meena Das','meena@example.com','Female','Chennai','2025-03-20'),
('Arjun Reddy','arjun@example.com','Male','Bengaluru','2025-04-02'),
('Sara Khan','sara@example.com','Female','Pune','2025-04-18');

INSERT INTO dbo.Products (ProductName,Category,UnitPrice,StockQuantity) VALUES
('Wireless Mouse','Electronics',799,50),('Keyboard','Electronics',1299,35),
('Notebook','Stationery',99,200),('Water Bottle','Lifestyle',399,80),
('USB-C Cable','Electronics',299,100);

INSERT INTO dbo.Orders (CustomerID,OrderDate,OrderStatus) VALUES
(1,'2025-05-01','Delivered'),(2,'2025-05-03','Shipped'),
(1,'2025-05-10','Processing'),(3,'2025-05-11','Cancelled'),
(4,'2025-05-12','Delivered'),(5,'2025-05-14','Pending');

INSERT INTO dbo.OrderItems (OrderID,ProductID,Quantity,UnitPrice) VALUES
(1,1,2,799),(1,3,5,99),(2,2,1,1299),(2,5,2,299),
(3,4,1,399),(3,1,1,799),(4,3,3,99),(5,2,1,1299),
(5,4,2,399),(6,5,1,299);
GO


SELECT * FROM dbo.Customers
SELECT * FROM dbo.Products
SELECT * FROM dbo.Orders
SELECT * FROM dbo.OrderItems
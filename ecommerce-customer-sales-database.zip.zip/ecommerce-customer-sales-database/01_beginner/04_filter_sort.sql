USE EcommerceDB;
GO

SELECT * FROM dbo.Customers;

SELECT CustomerName AS NAME ,City FROM dbo.Customers ORDER BY CustomerName;

SELECT DISTINCT City FROM dbo.Customers;

SELECT TOP(3) ProductName,UnitPrice FROM dbo.Products ORDER BY UnitPrice;

SELECT * FROM dbo.Products WHERE UnitPrice >=300;

SELECT * FROM dbo.Customers WHERE City IN('Bengaluru','Hyderabad');

SELECT * FROM dbo.Products WHERE ProductName LIKE '%C%'
 
SELECT * FROM dbo.Orders WHERE OrderDate BETWEEN '2025-05-01' AND '2025-05-10';

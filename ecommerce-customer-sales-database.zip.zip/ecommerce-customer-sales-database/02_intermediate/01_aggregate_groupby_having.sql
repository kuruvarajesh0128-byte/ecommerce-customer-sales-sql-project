USE EcommerceDB;
GO

SELECT COUNT(*) AS CustomerCount FROM dbo.Customers

SELECT Category,AVG(UnitPrice) AS AveragePrice, MIN(UnitPrice) AS LowestPrice,MAX(UnitPrice) AS HighestPrice FROM Products GROUP BY Category

SELECT OrderStatus,COUNT(*) AS OrderCount FROM dbo.Orders GROUP BY OrderStatus HAVING COUNT(*)>=1
USE EcommerceDB;
GO

SELECT O.OrderID,C.CustomerName,O.OrderDate,O.OrderStatus FROM dbo.Orders O INNER JOIN dbo.Customers C ON C.CustomerID=O.CustomerID


SELECT C.CustomerName FROM dbo.Customers C
LEFT JOIN dbo.Orders O ON O.CustomerID=C.CustomerID WHERE O.OrderID IS NULL;


SELECT o.OrderID,c.CustomerName,p.ProductName,oi.Quantity,oi.UnitPrice,oi.Quantity*oi.UnitPrice AS LineTotal
FROM dbo.Orders o JOIN dbo.Customers c on c.customerID=o.CustomerID
JOIN dbo.OrderItems oi ON oi.OrderID=o.OrderID
JOIN dbo.Products p ON p.ProductID=oi.ProductID;

USE EcommerceDB;
GO

SELECT ProductName,UnitPrice,
 CASE WHEN UnitPrice>=1000 THEN 'PREMIUM'
      WHEN UnitPrice>=300 THEN  'STANDARD'
      ELSE 'BUDGET' 
 END AS PriceBrand
FROM dbo.Products


SELECT CustomerName,UPPER(CustomerName) AS UpperName,LEN(CustomerName) AS NameLength,
 CONCAT(CustomerName,' - ',COALESCE(City,'Unknown')) AS CustomerLabel
FROM dbo.Customers;



SELECT OrderID,OrderDate,YEAR(OrderDate) AS OrderYear,MONTH(OrderDate) AS OrderMonth,
 DATEDIFF(DAY,OrderDate,GETDATE()) AS DaysSinceOrder FROM dbo.Orders;

USE EcommerceDB;
GO


SELECT ProductName,Category,UnitPrice,
 ROW_NUMBER() OVER(PARTITION BY Category ORDER BY UnitPrice DESC) AS RowNum,
 RANK() OVER(PARTITION BY Category ORDER BY UnitPrice DESC) AS PriceRank,
 DENSE_RANK() OVER(PARTITION BY Category ORDER BY UnitPrice DESC) AS DensePriceRank
FROM dbo.Products;


WITH OrderTotals AS (
 SELECT o.OrderID,o.OrderDate,SUM(oi.Quantity*oi.UnitPrice) AS OrderTotal
 FROM dbo.Orders o JOIN dbo.OrderItems oi ON oi.OrderID=o.OrderID
 GROUP BY o.OrderID,o.OrderDate
)
SELECT OrderID,OrderDate,OrderTotal,
 SUM(OrderTotal) OVER(ORDER BY OrderDate,OrderID ROWS UNBOUNDED PRECEDING) AS RunningTotal,
 LAG(OrderTotal) OVER(ORDER BY OrderDate,OrderID) AS PreviousOrderTotal
FROM OrderTotals;

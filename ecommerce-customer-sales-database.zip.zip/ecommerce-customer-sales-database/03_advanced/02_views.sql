USE EcommerceDB;
GO


CREATE OR ALTER VIEW dbo.vw_OrderDetails AS
SELECT o.OrderID,c.CustomerName,o.OrderDate,o.OrderStatus,p.ProductName,
 oi.Quantity,oi.UnitPrice,oi.Quantity*oi.UnitPrice AS LineTotal
FROM dbo.Orders o JOIN dbo.Customers c ON c.CustomerID=o.CustomerID
JOIN dbo.OrderItems oi ON oi.OrderID=o.OrderID
JOIN dbo.Products p ON p.ProductID=oi.ProductID;
GO
SELECT * FROM dbo.vw_OrderDetails;

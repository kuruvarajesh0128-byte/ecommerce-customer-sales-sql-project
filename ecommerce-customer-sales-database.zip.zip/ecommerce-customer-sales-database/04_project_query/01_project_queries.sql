USE EcommerceDB;
GO


-- 1. Value of each order
SELECT o.OrderID,SUM(oi.Quantity*oi.UnitPrice) AS OrderValue
FROM dbo.Orders o JOIN dbo.OrderItems oi ON oi.OrderID=o.OrderID
GROUP BY o.OrderID ORDER BY OrderValue DESC;

-- 2. Delivered revenue
SELECT SUM(oi.Quantity*oi.UnitPrice) AS DeliveredRevenue
FROM dbo.Orders o JOIN dbo.OrderItems oi ON oi.OrderID=o.OrderID
WHERE o.OrderStatus='Delivered';

-- 3. Top products by units sold
SELECT TOP(5) p.ProductName,SUM(oi.Quantity) AS UnitsSold
FROM dbo.OrderItems oi JOIN dbo.Products p ON p.ProductID=oi.ProductID
GROUP BY p.ProductName ORDER BY UnitsSold DESC;

-- 4. Customer spend from delivered orders
SELECT c.CustomerName,COALESCE(SUM(oi.Quantity*oi.UnitPrice),0) AS LifetimeSpend
FROM dbo.Customers c
LEFT JOIN dbo.Orders o ON o.CustomerID=c.CustomerID AND o.OrderStatus='Delivered'
LEFT JOIN dbo.OrderItems oi ON oi.OrderID=o.OrderID
GROUP BY c.CustomerID,c.CustomerName ORDER BY LifetimeSpend DESC;

-- 5. Customers with multiple orders
SELECT c.CustomerName,COUNT(o.OrderID) AS OrderCount
FROM dbo.Customers c JOIN dbo.Orders o ON o.CustomerID=c.CustomerID
GROUP BY c.CustomerID,c.CustomerName HAVING COUNT(o.OrderID)>1;

-- 6. Sales value by category
SELECT p.Category,SUM(oi.Quantity*oi.UnitPrice) AS SalesValue
FROM dbo.OrderItems oi JOIN dbo.Products p ON p.ProductID=oi.ProductID
GROUP BY p.Category ORDER BY SalesValue DESC;
